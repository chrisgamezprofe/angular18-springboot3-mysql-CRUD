import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private baseURL = "http://localhost:8080/products";

  private http = inject(HttpClient)

  constructor() { }

  getAllProducts(): Observable<any>{
    return this.http.get(`${this.baseURL}`);
  }

  getProductById(id:string): Observable<any>{
    return this.http.get(`${this.baseURL}/${id}`);
  }

  createProduct(product:Object): Observable<Object>{
    return this.http.post(`${this.baseURL}`,product);
  }

  updateProduct(id:string,product:Object): Observable<Object>{
    return this.http.put(`${this.baseURL}/${id}`,product);
  }

  deleteProduct(id:string): Observable<Object>{
    return this.http.delete(`${this.baseURL}/${id}`);
  }
}
