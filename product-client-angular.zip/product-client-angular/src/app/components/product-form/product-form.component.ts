import { Component, inject, OnInit } from '@angular/core';
import { ProductService } from '../../services/product.service';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-product-form',
  standalone: true,
  imports: [FormsModule,RouterLink],
  templateUrl: './product-form.component.html',
  styleUrl: './product-form.component.css'
})
export class ProductFormComponent implements OnInit {

  product:any={name:'',price:0}
  isEditMode:boolean = false;

  private productService = inject(ProductService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get("id");
    if(id){
      this.isEditMode = true;
      this.productService.getProductById(id).subscribe((data)=>{
        this.product = data;
      });
    }
  }

  saveProduct(){
    if(this.isEditMode){
      this.productService.updateProduct(this.product.id,this.product).subscribe(()=>{
        this.router.navigate(['/']);
      });

    }else{
      this.productService.createProduct(this.product).subscribe(()=>{
        this.router.navigate(['/']);
      });
    }
  }

}
