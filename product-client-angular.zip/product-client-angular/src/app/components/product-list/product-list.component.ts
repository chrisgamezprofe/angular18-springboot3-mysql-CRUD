import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../services/product.service';
import { NgFor } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [NgFor,RouterLink],
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css',
  providers:[ProductService]
})
export class ProductListComponent implements OnInit {
  products: any[] = [];

  constructor(private productService:ProductService){}

  ngOnInit(): void {
    this.productService.getAllProducts().subscribe(data => {
      this.products = data;
      console.log(data)
    })
  }

  deleteProductById(id:string){
    this.productService.deleteProduct(id).subscribe(() => {
      this.products = this.products.filter(product => product.id !== id);
    });
  }

}
